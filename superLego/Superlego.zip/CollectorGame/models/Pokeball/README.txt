Thank you for downloading the Pokeball 3D Model.The ball in the scene was made for Blender and/or other 3D modeling systems.

This model are available for you to use for any of your projects, if you do use  this file, please send me the link where
this file is being used, and if used in a video, I ask that you add me to the credits. I'd like to see what you guys come up with.

If you have any questions or comments about the model, you can email me at crew.christobel@mail.com 