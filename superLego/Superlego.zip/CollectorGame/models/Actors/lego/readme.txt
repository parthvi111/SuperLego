//////////////////////////////////////
//
//	3D Game Development 
//	Elaine Kang
//	CS, CSULA
//
//////////////////////////////////////

Model : [model-name].egg
Animations: other egg files

Usages:

1) pview Brawler.egg

or 

2) pview Brawler.egg Brawler-walk.egg


**** In pview press L to enable light. ****