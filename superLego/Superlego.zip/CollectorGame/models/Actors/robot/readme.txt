//////////////////////////////////////
//
//	3D Game Development 
//	Elaine Kang
//	CS, CSULA
//
//////////////////////////////////////

Model : lack.egg
Animations: other egg files

Try

1) pview lack.egg

or 

2) pview lack.egg leack-jump.egg
