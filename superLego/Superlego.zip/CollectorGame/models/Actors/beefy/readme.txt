//////////////////////////////////////
//
//	3D Game Development 
//	Elaine Kang
//	CS, CSULA
//
//////////////////////////////////////

Model : beefy.egg
Animations: other egg files

Try

1) pview beefy.egg

or 

2) pview beefy.egg beefy-walk.egg