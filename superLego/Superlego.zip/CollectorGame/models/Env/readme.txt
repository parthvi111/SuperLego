//////////////////////////////////////
//
//	3D Game Development 
//	Elaine Kang
//	CS, CSULA
//
//////////////////////////////////////

Model : [XXX].egg


Try 'pview [XXX].egg'

Use mouse buttons to change the camera's view.

