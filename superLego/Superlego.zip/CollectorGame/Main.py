
from pandac.PandaModules import loadPrcFileData

loadPrcFileData("", "sync-video t")

import sys
import time, math
import direct.directbase.DirectStart

from direct.actor.Actor import Actor
from direct.showbase.DirectObject import DirectObject
from direct.showbase.InputStateGlobal import inputState

from panda3d.core import AmbientLight
from panda3d.core import DirectionalLight
from panda3d.core import Vec3
from panda3d.core import Vec4
from panda3d.core import Point3
from panda3d.core import TransformState
from panda3d.core import BitMask32
from panda3d.core import Filename
from panda3d.core import PNMImage

from panda3d.bullet import BulletWorld
from panda3d.bullet import BulletPlaneShape
from panda3d.bullet import BulletBoxShape
from panda3d.bullet import BulletRigidBodyNode
from panda3d.bullet import BulletDebugNode
from panda3d.bullet import BulletCapsuleShape
from panda3d.bullet import BulletCharacterControllerNode
from panda3d.bullet import BulletHeightfieldShape
from panda3d.bullet import BulletTriangleMesh
from panda3d.bullet import BulletTriangleMeshShape
from panda3d.bullet import ZUp
from panda3d.bullet import BulletSphereShape
from panda3d.bullet import BulletCylinderShape
from panda3d.bullet import BulletConeShape


from panda3d.core import PandaNode,NodePath,Camera,TextNode, PerspectiveLens
from direct.gui.DirectGui import *
from direct.gui.OnscreenText import OnscreenText
from panda3d.core import AudioSound, WindowProperties
from panda3d.core import TransparencyAttrib

import sys, random, webbrowser

class Main(DirectObject):

	def __init__(self):
		base.setFrameRateMeter(True)
		visualNP = loader.loadModel('models/sky/sky.egg')
		visualNP.reparentTo(render)

		base.cam.setPos(0, -20, 5)
		base.cam.lookAt(0, 0, 0)

		# Light
		alight = AmbientLight('ambientLight')
		alight.setColor(Vec4(0.5, 0.5, 0.5, 1))
		alightNP = render.attachNewNode(alight)

		dlight = DirectionalLight('directionalLight')
		dlight.setDirection(Vec3(1, 1, -1))
		dlight.setColor(Vec4(0.7, 0.7, 0.7, 1))
		dlightNP = render.attachNewNode(dlight)

		render.clearLight()
		render.setLight(alightNP)
		render.setLight(dlightNP)

		self.curScore = 0
		self.legos =  3

		self.enableAudio = True
		self.start = True

		self.themeSong = loader.loadMusic('audio/game.wav')
		self.collectSound = loader.loadSfx("audio/collect.wav")
		self.dieSound = loader.loadSfx("audio/die.wav")
		self.themeSong.setVolume(0.4)
		self.collectSound.setVolume(1.0)

		if self.enableAudio:
			if not self.themeSong.status() == self.themeSong.PLAYING:
				#self.sfxManagerList[0].update()
				self.themeSong.play()

		self.setupInput()

		self.isMoving = False

		self.setupLevel1()
		
		# Task
		taskMgr.add(self.update, 'updateWorld')
		taskMgr.add(self.startMenu, 'startMenu')
		


		
	def setCamera(self):
		self.floater = NodePath(PandaNode("floater"))
		self.floater.reparentTo(self.actorNP)
		base.camera.reparentTo(self.floater)
		base.camera.setPos(0,45,10)

		self.floater.setPos(self.actorNP.getPos() + Vec3(0,0,10))
		base.camera.lookAt(self.floater)
		base.disableMouse()


	def setupInput(self):
		self.accept('escape', self.doExit)
		self.accept('r', self.doResetLevel1)
		self.accept('f1', self.toggleWireframe)
		self.accept('f2', self.toggleTexture)
		#self.accept('f3', self.toggleDebug)
		self.accept('f5', self.doScreenshot)

		self.accept('space', self.doJump)

		inputState.watchWithModifiers('forward', 'w')
		inputState.watchWithModifiers('left', 'a')
		inputState.watchWithModifiers('reverse', 's')
		inputState.watchWithModifiers('right', 'd')
		inputState.watchWithModifiers('turnLeft', 'q')
		inputState.watchWithModifiers('turnRight', 'e')

	
	def doExit(self):
		if not self.dieSound.status() == AudioSound.PLAYING:
			if self.enableAudio:
				self.dieSound.play()
				self.themeSong.stop()

		self.cleanup()
		game_over = OnscreenImage(image='images/game_over.png', pos=(0, 0, 0), scale=(1.4, 1, 1))
		game_over.reparentTo(aspect2d)

		game_over.colorScaleInterval(4, Vec4(1, 1, 1, 1))
		#sys.exit(1)

	def cleanup(self):
		self.worldNP.removeNode()
		self.worldNP = None
		self.world = None	

	def doResetLevel1(self):
		self.cleanup()

		self.background.hide()
		self.startBut.hide()
		self.level1.hide()
		self.level2.hide()
		self.setupLevel1()

	def doResetLevel2(self):
		self.cleanup()

		self.background.hide()
		self.startBut.hide()
		self.level1.hide()
		self.level2.hide()
		self.setupLevel2()
		taskMgr.add(self.moveClouds, 'moveClouds')
		taskMgr.add(self.cloudContact, 'cloudContact')

	def toggleWireframe(self):
		base.toggleWireframe()

	def toggleTexture(self):
		base.toggleTexture()

	def toggleDebug(self):
		if self.debugNP.isHidden():
			self.debugNP.show()
		else:
			self.debugNP.hide()

	def doScreenshot(self):
		base.screenshot('Bullet')


	def doJump(self):
		self.character.setMaxJumpHeight(5.0)
		self.character.setJumpSpeed(8.0)
		self.character.doJump()

	def update(self, task):
		dt = globalClock.getDt()

		if self.world == None:
			game_over = OnscreenImage(image='images/game_over.png', pos=(0, 0, 0), scale=(1.4, 1, 1))
			game_over.reparentTo(aspect2d)
		
			game_over.colorScaleInterval(4, Vec4(1, 1, 1, 1))
		else:
			self.processInput(dt)
			self.world.doPhysics(dt, 4, 1./240.)
			self.processContacts()
			if (self.characterNP.getZ() < 0.0):
				self.legos -= 1
				self.legoCount["text"] = str(self.legos)
				if self.legos == 0:
					self.doExit()
				self.characterNP.setPos(self.charVar['Pos'])

		return task.cont

	def processInput(self, dt):
		speed = Vec3(0, 0, 0)
		omega = 0.0

		if inputState.isSet('forward'): speed.setY(5.0)
		if inputState.isSet('reverse'): speed.setY(-5.0)
		if inputState.isSet('left'): 
			speed.setX(-5.0)
			omega = self.actorNP.getH() + 100 * globalClock.getDt() 
		if inputState.isSet('right'): 
			speed.setX(5.0)
			omega = - (self.actorNP.getH() + 100 * globalClock.getDt())
		if inputState.isSet('turnLeft'): omega = 120.0
		if inputState.isSet('turnRight'): omega = -120.0

		if ((inputState.isSet('forward') != 0) or (inputState.isSet('left') != 0)
			or (inputState.isSet('right') != 0) or (inputState.isSet('reverse') != 0)):
			if self.isMoving is False:
				self.actorNP.loop("run")
				self.isMoving = True
		else:
			if self.isMoving:
				self.actorNP.stop()
				self.actorNP.pose("walk", 5)
				self.isMoving = False

		self.character.setAngularMovement(omega)
		self.character.setLinearMovement(speed, True)



	def processContacts(self):
		for i in range(25):
			if not self.gcoins[i] or not self.character:
				None
			else:
				result = self.world.contactTestPair(self.character, self.gcoins[i].node())
				if(result.getNumContacts()):
					if not self.collectSound.status() == AudioSound.PLAYING:
							if self.enableAudio:
								self.collectSound.play()
				for contact in result.getContacts():
					if(self.gcoins[i].getPos() == Vec3(-1,35,27)):
						text = OnscreenText(text = str("Yeye Congrats!"), scale = 0.2, pos = (0 , 0, 0))
						text.destroy()
						self.doResetLevel2()
					elif(self.gcoins[i].getPos() == Vec3(82,91,54)):
						text = OnscreenText(text = str("Finished The Game!"), scale = 0.2, pos = (0 , 0, 0))
					else:
						node0 = contact.getNode0()
						node1 = contact.getNode1()
						self.curScore += 1
						self.countLabel["text"] = str(self.curScore)
						self.removeNode(node1, i)



	def removeNode(self, node, i):
		self.world.removeRigidBody(node)
		self.rcoin = self.gcoins[i].node()
		if node == self.rcoin: self.gcoins[i] = None
		if node == self.character: self.character = None
		np = NodePath(node)
		np.removeNode()

	def createChar(self):
		h = 1.80
		w = 0.5
		shape = BulletCapsuleShape(w, h - 2 * w, ZUp)

		self.character = BulletCharacterControllerNode(shape, 0.4, 'Player')
		self.characterNP = self.worldNP.attachNewNode(self.character)
		self.characterNP.setPos(-5,0,5)
		self.characterNP.setH(90)
		self.characterNP.setCollideMask(BitMask32.allOn())
		self.world.attachCharacter(self.character)

		self.actorNP = Actor('models/Actors/lego/Bricker/Bricker3.egg', {
							'walk' : 'models/Actors/lego/Bricker/BrickerWalk.egg',
							'run' : 'models/Actors/lego/Bricker/BrickerRun.egg',
							'jump' : 'models/Actors/robot/BrickerJump.egg'})
		self.actorNP.reparentTo(self.characterNP)
		self.actorNP.setScale(0.3048)
		self.actorNP.setH(180)
		self.actorNP.setPos(0, 0, 0.4)

		self.charVar = {'health': 100, 'bonus': 0, 'Pos': Vec3(-5,0 ,35), 'game_over': False,
                          'level_up': False, 'Score': 0}






	def setupLevel1(self):
		self.worldNP = render.attachNewNode('World')

		self.world = BulletWorld()
		self.world.setGravity(Vec3(0, 0, -9.81))


		# Box 
		self.box1 = self.createRectangles(Vec3(15, 0.6, 1.2), Vec3(-30,0,0))
		self.box2 = self.createRectangles(Vec3(30, 1.2, 2.4), Vec3(-45, 35, 13))
		self.box2.setHpr(0,90,0)

		# Character
		self.createChar()

		# Camera Setup
		self.setCamera()


		# Disk
		self.createDisk(Vec3(1.5, 0.1, ZUp), Vec3(-5, 0, 2))


		# Rotating Disks

		self.rDisks = [None,]*3

		for i in range(3):
			shape = BulletCylinderShape(4, 0.2, ZUp)

			np = self.worldNP.attachNewNode(BulletRigidBodyNode('Cylinder'))
			np.node().addShape(shape)
			np.setCollideMask(BitMask32.allOn())

			self.world.attachRigidBody(np.node())

			self.rDisks[i] = np

			self.rDisksVisualNP = loader.loadModel('models/Env/disk/disk.egg')
			self.rDisksVisualNP.setScale(2)
			self.rDisksVisualNP.reparentTo(np)
			
			tex = loader.loadTexture('models/wood.png')
			self.rDisksVisualNP.setTexture(tex, 1)

		self.rDisks[0].setPos(-31,10,2.2)
		rotation_interval = self.rDisks[0].hprInterval(5,Vec3(220,0,0))
		rotation_interval.loop()
		self.rDisks[1].setPos(-75,10,15)
		self.rDisks[2].setPos(-75,25,15)


		# Pyramid

		self.pyramid = [None,]*5
		for i in range(1,5):
			z = float(i*0.2) 
			shape = BulletBoxShape(Vec3(i*2, i*2, z))

			np = self.worldNP.attachNewNode(BulletRigidBodyNode('Box'))
			np.node().addShape(shape)
			np.setCollideMask(BitMask32.allOn())

			self.world.attachRigidBody(np.node())

			self.pyramid[i] = np

			visualNP = loader.loadModel('models/d.x')
			visualNP.setScale(i*2)
			visualNP.reparentTo(np)

			myTexture = loader.loadTexture("models/wood.png")
			visualNP.setTexture(myTexture, 1)

		self.pyramid[1].setPos(-1,35,24)
		self.pyramid[2].setPos(-1,35,21)
		self.pyramid[3].setPos(-1,35,18)
		self.pyramid[4].setPos(-1,35,15)

		# Gold Coins

		self.gcoins = [None,]*25

		for i in range(25):
			shape = BulletCylinderShape(0.55, 0.1, ZUp)

			np = self.worldNP.attachNewNode(BulletRigidBodyNode('Cylinder'))
			np.node().addShape(shape)
			np.setHpr(90, 90, 0)
			np.setCollideMask(BitMask32.allOn())

			self.world.attachRigidBody(np.node())

			self.gcoins[i] = np

			self.gcoinsVisualNP = loader.loadModel('models/coin.x')
			self.gcoinsVisualNP.setScale(0.4)
			self.gcoinsVisualNP.reparentTo(np)

		self.gcoins[0].setPos(-16,0,2.2)
		self.gcoins[1].setPos(-21,0,2.2)
		self.gcoins[2].setPos(-26,0,2.2)
		self.gcoins[3].setPos(-31,0,2.2)
		self.gcoins[4].setPos(-36,0,2.2)
		self.gcoins[5].setPos(-41,0,2.2)
		self.gcoins[6].setPos(-50,0,5)
		self.gcoins[7].setPos(-50,2,5)
		self.gcoins[8].setPos(-50,-2,5)
		self.gcoins[9].setPos(-57,0,12)
		self.gcoins[10].setPos(-57,2,12)
		self.gcoins[11].setPos(-57,-2,12)
		self.gcoins[12].setPos(-33,10,3.5)
		self.gcoins[13].setPos(-29,10,3.5)
		self.gcoins[14].setPos(-72,10,17)
		self.gcoins[15].setPos(-78,10,17)
		self.gcoins[16].setPos(-72,25,17)
		self.gcoins[17].setPos(-78,25,17)
		self.gcoins[18].setPos(-48,35,15)
		self.gcoins[19].setPos(-58,35,15)
		self.gcoins[20].setPos(-68,35,15)
		self.gcoins[21].setPos(-10,35,17)
		self.gcoins[22].setPos(-7,35,19)
		self.gcoins[23].setPos(-4,35,23)
		self.gcoins[24].setPos(-1,35,27)

		self.setupGui()

		# Stair
		origin = Point3(50, 0, 4)
		size = Vec3(2, 4.75, 1)
		shape = BulletBoxShape(size * 0.55)
		for i in range(10):
			pos = origin + size * i
			pos.setY(0)
			pos.setX(pos.getX()*-1)
			stairNP = self.worldNP.attachNewNode(BulletRigidBodyNode('Stair%i' % i))
			stairNP.node().addShape(shape)
			stairNP.setPos(pos)
			stairNP.setCollideMask(BitMask32.allOn())

			modelNP = loader.loadModel('models/box.egg')
			modelNP.reparentTo(stairNP)
			# modelNP.setPos(0, 0, 0)
			modelNP.setPos(-size.x/2.0, -size.y/2.0, -size.z/2.0)
			modelNP.setScale(size)
			self.world.attachRigidBody(stairNP.node())



	def setupLevel2(self):
		self.worldNP = render.attachNewNode('World')

		# World
		self.debugNP = self.worldNP.attachNewNode(BulletDebugNode('Debug'))
		self.debugNP.show()

		self.world = BulletWorld()
		self.world.setGravity(Vec3(0, 0, -9.81))
		#self.world.setDebugNode(self.debugNP.node())


		# Clouds
		self.clouds = []

		self.cloud1 = self.movingCloud(Vec3(0,0,0), Vec3(-5,0,2),'cloud',Vec3(0,0,0),Vec3(-5, 0, 25), Vec3(-5, 0, 2), Vec3(0, 0, .1))
		self.cloud2 = self.movingCloud(Vec3(0,0,0), Vec3(-15,12,25),'cloud',Vec3(0,90,0),Vec3(40,12,25), Vec3(-15,12,25), Vec3(.1, 0, 0))


		# Character
		self.createChar()
		self.setCamera()

		# #enemy

		h = 1.80
		w = 0.5
		shape = BulletCapsuleShape(w, h - 2 * w, ZUp)

		self.character1 = BulletCharacterControllerNode(shape, 0.4, 'Player')
		self.characterNP1 = self.worldNP.attachNewNode(self.character1)
		self.characterNP1.setPos(100,18,45)
		self.characterNP1.setH(90)
		self.characterNP1.setCollideMask(BitMask32.allOn())
		self.world.attachCharacter(self.character1)

		self.actorNP1 = Actor('models/Actors/lego/SecurityGuard/SecurityGuard.egg', {
							'walk' : 'models/Actors/lego/SecurityGuard/SecurityGuard-walk.egg'})
		self.actorNP1.reparentTo(self.characterNP1)
		self.actorNP1.setScale(0.3048)
		self.actorNP1.setH(180)
		self.actorNP1.setPos(0, 0, 0.5)

		# Rectangles

		self.block1 = self.createRectangles(Vec3(5,5,1), Vec3(-18, 0, 25))
		self.block12 = self.createRectangles(Vec3(2,2,1), Vec3(-18, 9, 25))
		self.block2 = self.createRectangles(Vec3(5,1,1), Vec3(30, 12, 28))
		self.block3 = self.createRectangles(Vec3(2,2,1), Vec3(55, 12, 30))

		self.block4 = self.movingCloud(Vec3(5,1,0.3), Vec3(60, 12, 28), 'rectangle',Vec3(0,0,0),Vec3(65,12,28), Vec3(60,12,28), Vec3(.1, 0, 0))
		
		self.block5 = self.createRectangles(Vec3(1,2,1), Vec3(72, 12, 30))
		self.block6 = self.createRectangles(Vec3(15,0.05,5), Vec3(95, 8, 35))

		self.block7 = self.createRectangles(Vec3(5,3,1), Vec3(85, 11, 30))
		self.block8 = self.createRectangles(Vec3(2,1,1), Vec3(95, 9, 33))
		self.block9 = self.createRectangles(Vec3(2,1,1), Vec3(102, 9, 36))
		self.block10 = self.createRectangles(Vec3(2,1,1), Vec3(95, 9, 39))
		self.block11 = self.createRectangles(Vec3(1,1,1), Vec3(100, 40, 40))
		# Rotating Disks

		self.disk1 = self.createDisk(Vec3(4,0.1, 0), Vec3(45, 12, 30))
		self.disk2 = self.createDisk(Vec3(4,0.1, 0), Vec3(100, 18, 40))
		self.disk3 = self.createDisk(Vec3(4,0.1, 0), Vec3(100, 30, 40))
		rotation_interval = self.disk1.hprInterval(5,Vec3(220,0,0))
		rotation_interval.loop()



		# Gold Coins

		self.gcoins = [None,]*25

		for i in range(25):
			shape = BulletCylinderShape(0.55, 0.1, ZUp)

			np = self.worldNP.attachNewNode(BulletRigidBodyNode('Cylinder'))
			np.node().addShape(shape)
			np.setHpr(90, 90, 0)
			np.setCollideMask(BitMask32.allOn())

			self.world.attachRigidBody(np.node())

			self.gcoins[i] = np

			self.gcoinsVisualNP = loader.loadModel('models/coin.x')
			self.gcoinsVisualNP.setScale(0.4)
			self.gcoinsVisualNP.reparentTo(np)

		self.gcoins[0].setPos(-5,0,10)
		self.gcoins[1].setPos(-5,0,25)
		self.gcoins[2].setPos(-18,0,27)
		self.gcoins[3].setPos(-22,4,27)
		self.gcoins[4].setPos(-14,-4,27)
		self.gcoins[5].setPos(30,12,33)
		self.gcoins[6].setPos(45,14,33)
		self.gcoins[7].setPos(45,10,33)
		self.gcoins[8].setPos(55,12,35)
		self.gcoins[9].setPos(65,12,35)
		self.gcoins[10].setPos(72,12,35)
		self.gcoins[11].setPos(85,11,35)
		self.gcoins[12].setPos(95,9,35)
		self.gcoins[13].setPos(102,9,39)
		self.gcoins[14].setPos(95,9,42)
		self.gcoins[15].setPos(100,16,44)
		self.gcoins[16].setPos(100,20,44)
		self.gcoins[17].setPos(100,28,44)
		self.gcoins[18].setPos(100,32,44)
		self.gcoins[19].setPos(100,40,45)
		self.gcoins[20].setPos(100,48,45)
		self.gcoins[21].setPos(94,65,45)
		self.gcoins[22].setPos(88,80,50)
		self.gcoins[23].setPos(84,82,50)
		self.gcoins[24].setPos(82,91,54)

		origin = Point3(-100, 48, 40)
		size = Vec3(2, 4.75, 1)
		shape = BulletBoxShape(size * 0.55)
		for i in range(10):
			pos = origin + size * i
			pos.setX(pos.getX()*-1)
			stairNP = self.worldNP.attachNewNode(BulletRigidBodyNode('Stair%i' % i))
			stairNP.node().addShape(shape)
			stairNP.setPos(pos)
			stairNP.setCollideMask(BitMask32.allOn())

			modelNP = loader.loadModel('models/box.egg')
			modelNP.reparentTo(stairNP)
			# modelNP.setPos(0, 0, 0)
			modelNP.setPos(-size.x/2.0, -size.y/2.0, -size.z/2.0)
			modelNP.setScale(size)
			self.world.attachRigidBody(stairNP.node())


	def createRectangles(self, size, position):
		shape = BulletBoxShape(size)
		
		np = self.worldNP.attachNewNode(BulletRigidBodyNode('Box'))
		np.node().addShape(shape)
		np.setPos(position)
		np.setCollideMask(BitMask32.allOn())

		self.world.attachRigidBody(np.node())

		visualNP = loader.loadModel('models/stone-cube/stone.egg')
		visualNP.setScale(size * 2)
		visualNP.reparentTo(np)
		visualNP.setPos(0,0,-(size.getZ()))

		return np


	def createDisk(self, size, position):


		shape = BulletCylinderShape(size.getX(), size.getY(), ZUp)

		np = self.worldNP.attachNewNode(BulletRigidBodyNode('Cylinder'))
		np.setPos(position)
		np.node().addShape(shape)
		np.setCollideMask(BitMask32.allOn())

		self.world.attachRigidBody(np.node())

		self.rDisksVisualNP = loader.loadModel('models/Env/disk/disk.egg')
		self.rDisksVisualNP.setScale(size.getX() / 2)
		self.rDisksVisualNP.reparentTo(np)

		tex = loader.loadTexture('models/wood.png')
		self.rDisksVisualNP.setTexture(tex, 1)

		return np



	def createCloud(self, position, hpr=Vec3(0,0,0)):
		shape = BulletCylinderShape(2, 2.5, ZUp)

		self.disk = self.worldNP.attachNewNode(BulletRigidBodyNode('Cylinder'))
		self.disk.node().addShape(shape)
		self.disk.setPos(position)
		self.disk.setCollideMask(BitMask32.allOn())

		self.world.attachRigidBody(self.disk.node())

		self.diskvisualNP = loader.loadModel('models/cloud.x')
		self.diskvisualNP.setScale(2)
		self.diskvisualNP.clearModelNodes()
		self.diskvisualNP.reparentTo(self.disk)

		return self.disk


	def movingCloud(self,size,position,typeValue, hpr=Vec3(0,0,0),maxPos=Vec3(0, 0, 0),
		minPos=Vec3(0, 0, 0), path=Vec3(0, 0, 0)):

		if typeValue == 'cloud':
			cloud = self.createCloud(position)
		elif typeValue == 'rectangle':
			cloud = self.createRectangles(size,position)

		cloudVar = {'cloudNP' : cloud, 'max': maxPos, 'min': minPos, 'path': path}

		self.clouds.append(cloudVar)

		return cloud


	def moveClouds(self, task):
		for cloudVar in self.clouds:
			min_x = cloudVar['min'].getX()
			min_y = cloudVar['min'].getY()
			min_z = cloudVar['min'].getZ()

			max_x = cloudVar['max'].getX()
			max_y = cloudVar['max'].getY()
			max_z = cloudVar['max'].getZ()

			position = cloudVar['cloudNP'].getPos()

			pos_x = position.getX()
			pos_y = position.getY()
			pos_z = position.getZ()

			move_x = cloudVar['path'].getX()
			move_y = cloudVar['path'].getY()
			move_z = cloudVar['path'].getZ()


			if pos_x + move_x > max_x:
				cloudVar['path'].setX(move_x * -1)
			elif pos_x + move_x < min_x:
				cloudVar['path'].setX(move_x * -1)

			if pos_y + move_y > max_y:
				cloudVar['path'].setY(move_y * -1)
			elif pos_y + move_y < min_y:
				cloudVar['path'].setY(move_y * -1)

			if pos_z + move_z > max_z:
				cloudVar['path'].setZ(move_z * -1)
			elif pos_z + move_z < min_z:
				cloudVar['path'].setZ(move_z * -1)

			cloudVar['cloudNP'].setPos(position + cloudVar['path'])

		return task.cont


	def cloudContact(self, task):
		if self.world != None:
			for cloudVar in self.clouds:
				node1 = cloudVar['cloudNP'].node()
				contact = self.world.contactTestPair(self.character, node1)

				if len(contact.getContacts()) > 0 and node1.getCollisionResponse():
					self.characterNP.setPos(self.characterNP.getPos() + cloudVar['path'])
		return task.cont

	def startMenu(self, task):
		if self.start:
			self.background = OnscreenImage(image='models/lego.jpg', pos=(0, 0, 0), scale=(1.4, 1, 1))
			maps = loader.loadModel('models/button_maps')
			self.startBut = DirectButton(geom = (maps.find('**/but_steady'),maps.find('**/but_click'),maps.find('**/but_hover'),  maps.find('**/but_disable')), scale = 0.2, text = "Start Game", text_scale = 0.2, pos = (0, 0, 0.3), command = self.doResetLevel1)
			self.level1 = DirectButton(geom = (maps.find('**/but_steady'),maps.find('**/but_click'),maps.find('**/but_hover'),  maps.find('**/but_disable')), scale = 0.2, text = "Level1", text_scale = 0.2, pos = (0, 0, 0.1), command = self.doResetLevel1)
			self.level2 = DirectButton(geom = (maps.find('**/but_steady'),maps.find('**/but_click'),maps.find('**/but_hover'),  maps.find('**/but_disable')), scale = 0.2, text = "Level2", text_scale = 0.2, pos = (0, 0, -0.1), command = self.doResetLevel2)

	def setupGui(self):
		OnscreenImage(parent = render2dp, image = 'models/coin.png', pos = (-0.90, 0, 0.8), scale = (0.09, 0.09, 0.09))
		self.countLabel = DirectLabel(text = str(self.curScore), scale = 0.2, pos = (-1 , 0, 0.75))
		DirectLabel(text = str('/25'), scale = 0.15, pos = (-0.8 , 0, 0.75))

		OnscreenImage(parent = render2dp, image = 'images/lego.png', pos = (-0.90, 0, -0.8), scale = (0.09, 0.03, 0.14))
		self.legoCount = DirectLabel(text = str(self.legos), scale = 0.2, pos = (-1 , 1, -0.8))


        
main = Main()
run()